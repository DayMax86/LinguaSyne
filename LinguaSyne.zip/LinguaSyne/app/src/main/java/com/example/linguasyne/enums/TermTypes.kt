package com.example.linguasyne.enums

enum class TermTypes {
    NOUN,
    ADJ,
    ADV,
    VERB,
    INTERJ,
    EXPR
}