package com.example.linguasyne.enums

enum class Gender {
    M, F, NO, MF
}