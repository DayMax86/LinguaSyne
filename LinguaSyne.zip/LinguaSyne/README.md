# LinguaSyne
LinguaSyne is a WIP language-learning app that uses an SRS (Spaced Repetition System) and mnemonics to help users remember vocabulary and phrases. The app is being developed with French as the language to learn, but hopefully it will be the first language of many!

The app uses Firebase to allow users to have accounts and securely log in, as well as to store all the linguistic data that the app uses to teach the language.
Other features/tools used include Unit tests, RecyclerViews, reading from files, version control through Git etc. Soon it will feature API calls and other features of modern app design.
